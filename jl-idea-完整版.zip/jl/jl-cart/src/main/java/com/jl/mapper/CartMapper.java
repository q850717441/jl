package com.jl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jl.pojo.Cart;

/**
 * @program: jl
 * @author: JL
 * @create: 2019-11-19 10:01
 * @description:
 **/
public interface CartMapper extends BaseMapper<Cart> {
}
