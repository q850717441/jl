package com.jl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jl.pojo.ItemCat;

public interface ItemCatMapper extends BaseMapper<ItemCat>{

}
