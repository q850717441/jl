package com.jl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jl.pojo.ItemDesc;

public interface ItemDescMapper extends BaseMapper<ItemDesc>{

}
